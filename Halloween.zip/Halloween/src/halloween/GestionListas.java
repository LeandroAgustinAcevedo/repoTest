package halloween;

import java.util.List;

public class GestionListas {
    
    // upper bound wildcard
    public static void iniciarHalloween(List<? extends Criatura> lista){
        for(Criatura cr : lista){
            cr.asustar();
        }
    }
    
    public static void materializarLista(List<? extends Espectro> lista){
        for(Espectro esp : lista){
            esp.materializar();
        }
    }
    
    public static void fantasmearLista(List<? extends Fantasma> lista){
        for(Fantasma fant : lista){
            fant.fantasmear();
        }
    }
    
    public static void liberarAterradores(List<? extends Aterrable> lista){
        for(Aterrable at : lista){
            at.aterrar();
        }
    }
    
    // lower bound wildcard
    public static <T> void agregarElemento(List<? super T> lista, T nuevo){
        lista.add(nuevo);
    }
    
    
}

package halloween;

public class Espectro extends Criatura implements Aterrable{
    
    private int nivelEspiritual;

    public Espectro(String nombre, int energia, int nivelEspiritual) {
        super(nombre, energia);
        this.nivelEspiritual = nivelEspiritual;
    }
    
    @Override
    public String toString() {
        return "Espectro{"+ "nombre=" + getNombre() + ", nivelEspiritual=" + nivelEspiritual + '}';
    }
    
    public void materializar(){
        System.out.println("Soy un espectro de nivel " + nivelEspiritual + ", y me materializo para que te mueras de miedo");
    }

    @Override
    public void aterrar() {
        System.out.println("Soy " + getNombre() + ", y aterro a todos en Halloween!!!");
    }
}

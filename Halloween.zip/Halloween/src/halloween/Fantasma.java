package halloween;

public class Fantasma extends Espectro{
    
    private double transparencia;
    
    public Fantasma(String nombre, int energia, int nivelEspiritual, double transparencia) {
        super(nombre, energia, nivelEspiritual);
        this.transparencia = transparencia;
    }
    
    public void fantasmear(){
        System.out.println("Mi transparencia es " + transparencia + " y floto por la habitacion");
    }

    @Override
    public String toString() {
        return "Fantasma{" + "nombre=" + getNombre() + ", transparencia=" + transparencia + '}';
    }
    
}

package halloween;

public interface Aterrable {

    void aterrar();
}
